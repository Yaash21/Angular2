export interface ServiceInterface{

id:number;
restaurantName:string;
restaurantLocation:string;
costOfTwo:number;

}
